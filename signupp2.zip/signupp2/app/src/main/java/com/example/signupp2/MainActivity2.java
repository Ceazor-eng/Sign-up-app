package com.example.signupp2;

import static com.example.signupp2.R.id.Courses;
import static com.example.signupp2.R.id.Gender;
import static com.example.signupp2.R.id.age;
import static com.example.signupp2.R.id.imageView;
import static com.example.signupp2.R.id.imageView2;
import static com.example.signupp2.R.id.name;
import static com.example.signupp2.R.id.phone;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import androidx.annotation.NonNull;
import android.net.Uri;
import android.Manifest;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityCompat;
import android.widget.Toast;
public class MainActivity2 extends AppCompatActivity {
    private Button email_button, callbtn;
    ImageView imageView2;
    private TextView nameTextview;
    private TextView ageTextview;
    private TextView phoneTextview;
    private TextView genderTextview;

    public static Uri imageUri;
    public static Bitmap imageBitmap;
    private TextView CoursesTextview;

    private static final int REQUEST_CALL_PHONE_PERMISSION = 1;




    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        nameTextview = findViewById(R.id.name);
        imageView2 = findViewById(R.id.imageView2);
        genderTextview = findViewById(R.id.Gender);
        phoneTextview = findViewById(R.id.phone);
        ageTextview = findViewById(R.id.age);
        CoursesTextview = findViewById(R.id.Courses);
        email_button = findViewById(R.id.email_button);
        callbtn = findViewById(R.id.callbtn);


        // Get the extras passed in the intent
        Intent intent = getIntent();
        String nameString = intent.getStringExtra("name");
        String phoneString = getIntent().getStringExtra("phone");
        int age = getIntent().getIntExtra("age", 0);
        String GenderString = getIntent().getStringExtra("selectedGender");
        String CoursesString = getIntent().getStringExtra("selectedCourse");

        nameTextview.setText("name: " + nameString);
        genderTextview.setText("Gender: " + GenderString);
        phoneTextview.setText("phone:" + phoneString);
        ageTextview.setText("age:" + age);
        CoursesTextview.setText("Courses:" + CoursesString);


        if (imageUri != null) {
            Log.e("image uri str - ", "1");
            imageView2.setImageURI(imageUri);
        } else {
            Log.e("image uri str - ", "2");
        }

        if (imageBitmap != null) {

            imageView2.setImageBitmap(imageBitmap);
        }


        email_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                sendEmail(emailString);

            }
        });

        callbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callPhone(phoneString);
            }
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CALL_PHONE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // call phone code
            } else {
                Toast.makeText(this, "CALL_PHONE permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void sendWhatsAppMessage(View view) {
        Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
        whatsappIntent.setType("text/plain");
        whatsappIntent.setPackage("com.whatsapp");
        whatsappIntent.putExtra(Intent.EXTRA_TEXT, "Hello from my app!");
        try {
            startActivity(whatsappIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "WhatsApp not installed.", Toast.LENGTH_SHORT).show();
        }
    }
    private void sendEmail(String email){
        Log.e("TIMO","about to send email");
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { email });
        intent.putExtra(Intent.EXTRA_SUBJECT, "RE:Greetings from my signup app");
        intent.putExtra(Intent.EXTRA_TEXT, "Hello! Welcome to my sign up app");
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
        Log.e("TIMO","opened email app");
    }


            private void callPhone(String phone){
        Log.e("TIMO","about to call::"+phone);

        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:"+phone));//change the number
        startActivity(callIntent);
    }




}

