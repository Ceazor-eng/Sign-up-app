package com.example.signupp2;

import static com.example.signupp2.R.id.age;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.example.signupp2.MainActivity2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
public class mainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Button pickDateBtn;
    private Button btn_take_photo, signupbtn;
    private RadioButton radio_button_male, radio_button_female;
    ImageView imageView;
    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 1;
    private static final int PICK_CONTACT = 2;


    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int REQUEST_IMAGE_CAPTURE = 2;
    private Uri imageUri;
    private Uri capturedImageUri;
    Button button;

    private EditText nameEditText;
    private TextView dob;
    private EditText phoneEditText;

    int age, year, month, dayOfMonth;
    private ArrayAdapter<String> coursesAdapter;
    private RadioGroup genderRadioGroup;

    private static final int PICK_IMAGE = 100;
    private DatePickerDialog datePickerDialog;
    private Spinner Courses;
    String courses = "";
    String Gender = "";


    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pickDateBtn = findViewById(R.id.idBtnPickDate);
        imageView = findViewById(R.id.imageView);
        dob = findViewById(R.id.dob);
        nameEditText = findViewById(R.id.name);
        phoneEditText = findViewById(R.id.phone);
        signupbtn = findViewById(R.id.signupbtn);
        Spinner spinner = findViewById(R.id.Courses);
        button = findViewById(R.id.btn_take_photo);
        radio_button_male = findViewById(R.id.radio_button_male);
        radio_button_female = findViewById(R.id.radio_button_female);


        Log.e("Courses", ">>>>>>>>>>>>" + Courses);
        spinner.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        categories.add("BBIT");
        categories.add("ACCOUNTING");
        categories.add("SOFTWARE ENGINEERING");
        categories.add("ACTURIAL SCIENCE");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(dataAdapter);

        setOnClickListeners();

    }

    private void launchCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                ex.printStackTrace();
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                imageUri = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        photoFile);
                capturedImageUri = imageUri;
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String imageFileName = "JPEG_" + System.currentTimeMillis() + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File imageFile = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        String currentPhotoPath = imageFile.getAbsolutePath();
        return imageFile;
    }

    private void launchGallery() {
        Intent pickPhotoIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickPhotoIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case REQUEST_IMAGE_CAPTURE:
                    imageView.setImageURI(capturedImageUri);
                    MainActivity2.imageUri = capturedImageUri;

                    break;

                case PICK_IMAGE_REQUEST:

                    imageUri = data.getData();
                    Log.e("image uri ", imageUri.toString());

                    imageView.setImageURI(imageUri);
                    MainActivity2.imageUri = imageUri;

                    break;

                default:
                    break;
            }
        }
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        courses = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), "Selected: " + courses, Toast.LENGTH_LONG).show();


    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    public void takePhoto(View view) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mainActivity.this);
                builder.setTitle("Select Image Source");
                builder.setItems(new CharSequence[]{"Gallery", "Camera"},
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which) {
                                    case 0:
                                        launchGallery();
                                        break;

                                    case 1:
                                        launchCamera();
                                        break;

                                    default:
                                        break;
                                }
                            }
                        });
                builder.show();
            }
        });
    }


    private void setOnClickListeners() {

        pickDateBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                datePickerDialog = new DatePickerDialog(mainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(year, month, dayOfMonth);
                        long dateInMillis = calendar.getTimeInMillis();
                        age = calculateAge(dateInMillis);

                    }

                    private int calculateAge(long dateInMillis) {
                        Calendar dob = Calendar.getInstance();
                        dob.setTimeInMillis(dateInMillis);

                        Calendar today = Calendar.getInstance();

                        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
                        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
                            age--;
                        }

                        return age;
                    }
                }, year, month, day);


                datePickerDialog.show();


            }


        });


        radio_button_male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Gender = "Male";
            }
        });


        radio_button_female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Gender = "Female";
            }
        });

        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(nameEditText.getText())) {
                    nameEditText.setError("Name is required");
                    nameEditText.requestFocus();
                    return;
                }
                if (pickDateBtn.getText().toString().equals(getString(R.string.select_date_of_birth))) {
                    Toast.makeText(mainActivity.this, "Please select date of birth", Toast.LENGTH_SHORT).show();
                    return;
                }
//                if (Courses.getSelectedItemPosition() == 0) {
//                    Toast.makeText(mainActivity.this, "Please select a course", Toast.LENGTH_SHORT).show();
//                    return;
//                }
                if (!radio_button_male.isChecked() && !radio_button_female.isChecked()) {
                    Toast.makeText(mainActivity.this, "Please select gender", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(phoneEditText.getText())) {
                    phoneEditText.setError("Phone number is required");
                    phoneEditText.requestFocus();
                    return;
                }
                {

                    Intent intent = new Intent(mainActivity.this, MainActivity2.class);
                    String name = nameEditText.getText().toString();
                    String phone = phoneEditText.getText().toString();
                    intent.putExtra("selectedGender", Gender);
                    intent.putExtra("selectedCourse", courses);
                    intent.putExtra("name", name);
                    intent.putExtra("phone", phone);
                    intent.putExtra("age", age);

                    startActivity(intent);


                }
            }
        });

    }
}





